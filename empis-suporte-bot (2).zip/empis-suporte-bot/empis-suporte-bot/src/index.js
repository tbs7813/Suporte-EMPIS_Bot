// Cloudflare Worker: recebe os avisos (webhook) da Meta e executa o bot.
import { createDb } from "./db.js";
import { createWa, verifySignature, parseWebhook } from "./whatsapp.js";
import { handleIncoming, handleEcho } from "./bot.js";

const OBRIGATORIAS = ["WHATSAPP_TOKEN", "PHONE_NUMBER_ID", "APP_SECRET", "VERIFY_TOKEN", "SUPABASE_URL", "SUPABASE_SERVICE_KEY"];

function faltando(env) {
  return OBRIGATORIAS.filter((k) => !env[k]);
}

async function processar(env, payload) {
  const db = createDb(env);
  const ctx = {
    db,
    wa: createWa(env),
    config: { notificar: env.NOTIFICAR_TECNICOS !== "false", pausarEco: env.PAUSAR_AO_RESPONDER_NO_APP === "true" },
  };
  const { messages, echoes } = parseWebhook(payload);
  for (const m of messages) {
    try {
      await handleIncoming(ctx, m);
    } catch (e) {
      console.error("erro ao processar mensagem", e?.message);
      try { await db.logError("handleIncoming", e?.message ?? String(e), { wamid: m.wamid }); } catch {}
      try { await ctx.wa.send(m.from, "Desculpe, ocorreu um erro temporário. Por favor, tente novamente em alguns instantes."); } catch {}
    }
  }
  for (const e of echoes) {
    try { await handleEcho(ctx, e); } catch (err) { console.error("erro no eco", err?.message); }
  }
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname === "/") return new Response("EMPIS Suporte Bot ativo.", { status: 200 });
    if (url.pathname !== "/webhook") return new Response("Não encontrado", { status: 404 });

    const f = faltando(env);
    if (f.length) {
      console.error("Segredos faltando:", f.join(", "));
      return new Response("Configuração incompleta", { status: 500 });
    }

    // Verificacao inicial feita pela Meta ao cadastrar o webhook
    if (request.method === "GET") {
      const mode = url.searchParams.get("hub.mode");
      const token = url.searchParams.get("hub.verify_token");
      const challenge = url.searchParams.get("hub.challenge");
      if (mode === "subscribe" && token === env.VERIFY_TOKEN && challenge) return new Response(challenge, { status: 200 });
      return new Response("Token inválido", { status: 403 });
    }

    if (request.method === "POST") {
      const raw = await request.text();
      const ok = await verifySignature(raw, request.headers.get("x-hub-signature-256"), env.APP_SECRET);
      if (!ok) return new Response("Assinatura inválida", { status: 401 });
      let payload;
      try { payload = JSON.parse(raw); } catch { return new Response("JSON inválido", { status: 400 }); }
      // Responde "OK" rapido para a Meta e processa em seguida
      ctx.waitUntil(processar(env, payload));
      return new Response("OK", { status: 200 });
    }

    return new Response("Método não permitido", { status: 405 });
  },

  // Tarefa diaria: acessa o banco para ele nao "dormir" por inatividade
  async scheduled(event, env, ctx) {
    ctx.waitUntil(createDb(env).ping().catch((e) => console.error("ping falhou", e?.message)));
  },
};
